<?php
$conn = mysqli_connect("localhost", "root", "", "maintanence");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $status = $_POST['status'];
    $rating = $_POST['rating'];
    $comments = $_POST['comments'];

    $sql = "INSERT INTO rating(name, status, rating, comments) VALUES ('$name','$status', '$rating', '$comments')";
    $data = mysqli_query($conn, $sql);

    if ($data) {
        echo "Data inserted successfully";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Rating</title>
    <style>
        
        nav {
            background-color: #3333;
            color: black;
            padding: 10px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        ul a {
            color: black;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        .rating-form {
            max-width: 100%;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            font-size: 13px;
        }

        input[type="text"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 13px;
        }

        select {
            height: 40px;
        }

        .rating {
            margin-top: 10px;
            display: flex;
            align-items: center;
        }

        .rating input[type="radio"] {
            display: none;
        }

        .rating label {
            font-size: 24px;
            cursor: pointer;
            color: #e4e4e4;
            margin-right: 5px;
            font-size: 13px;
        }

        .rating label:before {
            content: "";
        }

        .rating input[type="radio"]:checked ~ label {
            color: #ff9800;
        }

        .comment {
            margin-top: 10px;
        }

        .comment textarea {
            height: 100px;
        }

        .submit-button {
            background-color: #1c0d3f;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            font-size: 13px;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #160b2e;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .hamburger {
            font-size: 20px;
            cursor: pointer;
        }

        .show-menu {
            display: block !important;
        }

        .add-button,
        .remove-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 16px;
            margin-left: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        .remove-button {
            background-color: #f44336;
        }

        /* CSS styles for the sidenav */
        .sidenav {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #1c0d3f;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .sidenav a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 15px;
            color: #818181;
            display: block;
            transition: 0.3s;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }

        .sidenav .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        @media screen and (max-height: 450px) {
            .sidenav { padding-top: 15px; }
            .sidenav a { font-size: 18px; }
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const hamburger = document.querySelector(".hamburger");
            const menuItems = document.querySelector(".menu-items");

            hamburger.addEventListener("click", function () {
                menuItems.classList.toggle("show-menu");
            });
        });
    </script>
</head>
<body>
    <!-- Sidenav -->
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="supervisordashboard.php">Home</a>
        <a href="profile.php">My Profile</a>
        <a href="mainlogin.php">Logout</a>
        <!-- Add additional navigation links as needed -->
    </div>

    <header>
            <div class="menu-bar">
                <span class="hamburger" onclick="openNav()">&#8801;</span>
            </div>
    </header>

    <form action="" method="post" onsubmit="return submitRating()">
    <div class="rating-form">
            <h2>Rate Employee</h2>
            <div class="form-group">
                <label for="name">Employee Name:</label>
                <select id="name" name="name" required>
                    <?php
                    // Fetch worker names from the login table
                    $sql = "SELECT name FROM login WHERE role='worker'";
                    $result = mysqli_query($conn, $sql);

                    // Populate dropdown options dynamically
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value=\"{$row['name']}\">{$row['name']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
            </select>
        </div>
            <div class="form-group">
                <label for="rating">Rating:</label>
                <input type="text" id="rating" name="rating" min="1" max="5" placeholder="Enter rating (1-5)" required>
            </div>
            <div class="form-group comment">
                <label for="comments">Comments:</label>
                <textarea id="comments" name="comments" placeholder="Enter your comments"></textarea>
            </div>
            <input type="submit" value="Add" name="submit" class="submit-button" style="background-color: #1c0d3f;">
    </div>
    </form>
<div id="successMessage" style="display: none; text-align: center; padding: 10px; background-color: #4CAF50; color: white; margin-top: 10px;">
    Rating submitted successfully!
</div>
<script>
    function submitRating() {
        const employeeName = document.getElementById('name').value;
        const rating = document.getElementById('rating').value;
        const comment = document.getElementById('comments').value;
        if (!employeeName || !rating || !comment) {
            alert('Please fill in all fields.');
            return false; // Prevent form submission
        } else {
            // Show success message
            document.getElementById('successMessage').style.display = 'block';
            
            // You can submit the data to your server or perform other actions here.
            // In this example, I'm redirecting to the dashboard after a short delay.
            setTimeout(function () {
                window.location.href = 'supervisordashboard.php';
            }, 2000); // 2000 milliseconds (2 seconds) delay before redirecting

            return false; // Prevent form submission
        }
    }
</script>
    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "150px";
        }
        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
        function showPopup(message) {
            alert(message);
        }
    </script>
</body>
</html>
