<?php
$conn = mysqli_connect("localhost", "root", "", "maintanence");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to retrieve data from the 'login' table for active workers dropdown
$workerSql = "SELECT * FROM login WHERE role = 'worker' AND action = 'active'";
$workerResult = mysqli_query($conn, $workerSql);

// Query to retrieve data from the 'issue' table
$sql = "SELECT * FROM issue WHERE status != 'completed'";
$result = mysqli_query($conn, $sql);

// Handling form submission for assigning an issue to a worker
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedWorker = $_POST["worker"];
    $selectedIssueID = $_POST["issue"];

    // Update 'login' table with the selected worker for the specific issue
    $updateSql = "UPDATE login SET issue = '$selectedIssueID' WHERE name = '$selectedWorker' AND role = 'worker' AND action = 'active'";
    mysqli_query($conn, $updateSql);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search and Buttons Example</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        header {
            background-color: #1c0d3f;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav {
            background-color: #311249;
            color: white;
            padding: 10px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        ul a {
            color: white;
            text-decoration: none;
        }

        li {
            display: inline;
            margin-right: 20px;
            font-size: 13px;
        }

        main {
            padding: 20px;
        }

        .employee-table {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .employee-table h3 {
            margin-top: 0;
        }

        .employee-table table {
            width: 100%;
            border-collapse: collapse;
        }

        .employee-table th, .employee-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
            font-size: 13px;
        }

        .employee-table th {
            background-color: #f2f2f2;
        }

        button {
            background-color: #1c0d3f;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <h2>Electrical Maintenance</h2>
    </header>
    
    <nav>
        <ul>
        <li><a href="supervisordashboard.php">Home</a></li>
            <li><a href="choose.php">Assign Issue</a></li>
            <li><a href="mainstatus.php">Work Status</a></li>
            <li><a href="supervisoremployedetails.php">Employee Details</a></li>
            <li><a href="mainlogin.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <div class="employee-table">
            <h3>Issue Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Location</th>
                        <th>Equipment</th>
                        <th>Issue</th>
                        <th>Assign Worker</th> <!-- New column for worker dropdown -->
                    </tr>
                </thead>
                <tbody>
                    <!-- Loop through the data retrieved from the 'issue' table -->
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['user_id'] . "</td>";
                        echo "<td>" . $row['location'] . "</td>";
                        echo "<td>" . $row['eqname'] . "</td>";
                        echo "<td>" . $row['issue'] . "</td>";
                        echo "<td>";
                        echo "<form method='POST' action=''>";
                        echo "<select name='worker'>";

                        mysqli_data_seek($workerResult, 0);
                        
                        // Loop through the data retrieved from the 'login' table for workers dropdown
                        while ($workerRow = mysqli_fetch_assoc($workerResult)) {
                            echo "<option value='" . $workerRow['name'] . "'>" . $workerRow['name'] . "</option>";
                        }

                        echo "</select>";
                        echo "<input type='hidden' name='issue' value='" . $row['issue'] . "'>";
                        echo "<button type='submit'>Assign</button>";
                        echo "</form>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <!-- Your footer content goes here -->
    </footer>

    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "150px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
        function showPopup(message) {
            alert(message);
        }
    </script>
</body>
</html>
