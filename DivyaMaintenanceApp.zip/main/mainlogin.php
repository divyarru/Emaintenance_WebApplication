<?php
$conn = mysqli_connect("localhost", "root", "", "maintanence");
session_start();

if (!empty($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query = "SELECT * FROM login WHERE username='" . $username . "' AND password='" . $password . "'";
    $result = mysqli_query($conn, $query);
    
    // Check if the query returned any rows
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);
        if ($row["role"] == 'manager') {
            $_SESSION["username"] = $username;
            header('location: appdashboard.php');

        } elseif ($row["role"] == 'supervisor') {
            $_SESSION["username"] = $username;
           
            header('location: supervisordashboard.php');

        } elseif ($row["role"] == 'worker') {
            $_SESSION["username"] = $username;
       
            header('location: workerissue.php');
            
        } elseif ($row["role"] == 'user') {
            $_SESSION["username"] = $username;
       
            header('location: issue.php');
        }

    } else {
        // Display a pop-up message for invalid username/password
        echo '<script>alert("Invalid username or password");</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Electrical Equipment Maintenance</title>
    <style>
        body {
            max-width: max-content;
            margin: auto;
            margin-Top: 80px;
            background-color: #3F3064;
            font-size: 1.3em;
        }

        label {
    display: inline-block;
    width: 91px;
    font-size: smaller;
}

        #btn_s {
            width: 300px;
            height: 35px;
            background-color: #BDEEC5;
            font-size: 16px;
            font-face: bold;

        }

        #btn_i {
            width: 125px;
        }
    </style>
</head>
<body style="background-color: #1c0d3f;">
<p id="ground">
    <center>
        <br>
        <form method="post">
            <fieldset style="padding: 50px; border: 1px solid white; background: white; align: center;">
            <h4>Login</h4>
                <img
                        src="Creative_Color_Brushstroke_Lettering_Logo-removebg-preview.png"
                        width="300" height="250" style="background-color: transparent;">
                <div id="page">
                    <label for="username">Username:</label>
                    <input type="text" name="username" required><br><br>
                    <label for="password">Password:</label>
                    <input type="password" id="pass" name="password" required><br><br>
                    <input type="submit" name="submit" value="login">
                </div>
            </fieldset>
        </form>
    </center>
</p>
<script>
    function togglePasswordVisibility() {
        var passwordField = document.getElementById("pass");
        if (passwordField.type === "password") {
            passwordField.type = "text";
        } else {
            passwordField.type = "password";
        }
    }
    
    // Add JavaScript code to reload the page after the pop-up is dismissed
    var popUpMessage = document.querySelector('script');
    if (popUpMessage) {
        popUpMessage.addEventListener('click', function() {
            window.location.reload();
        });
    }
</script>
</body>
</html>
