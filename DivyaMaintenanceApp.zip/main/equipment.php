<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AC Equipment</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            font-size: 13px;
        }

        header {
            background-color: #1c0d3f;
            color: white;
            padding: 1px;
            text-align: center;
        }

        nav {
            background-color: #311249;
            color: white;
            padding: 1px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        ul a {
            color: white;
        }

        li {
            display: inline;
            margin-right: 20px;
            color: white;
            font-size: 13px;
        }

        a {
            text-decoration: none;
            color: #1c0d3f
        }

        .box {
            width: 150px;
            height: 180px;
            border: 1px solid #000;
            margin: 10px;
            padding: 10px;
            float: left;
        }

        .box img {
            max-width: 100%;
            max-height: 80px; /* Adjust the height as needed */
            display: block;
            margin: 0 auto;
        }

        .box a {
            text-decoration: none;
            color: inherit;
        }

        .search-bar {
            margin-bottom: 20px;
            text-align: center;
        }

        #search {
            padding: 8px;
            width: 50%;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
            font-size: 13px;
        }
    </style>
</head>

<body>
    <header>
        <h2>Electrical Maintenance</h2>
    </header>

    <nav>
        <ul>
            <li><a href="supervisordashboard.php">Home</a></li>
            <li><a href="viewissue.php">View Issue</a></li>
            <li><a href="mainstatus.php">Work Status</a></li>
            <li><a href="supervisoremployedetails.php">Employee Details</a></li>
            <li><a href="mainlogin.php">Logout</a></li>
        </ul>
    </nav>
    <br></br>
    <div class="search-bar">
    <form action="" method="GET">
    <input type="hidden" name="equipment" value="<?php echo isset($_GET['equipment']) ? htmlspecialchars($_GET['equipment']) : ''; ?>">
    <input type="text" id="search" name="search" placeholder="Search...">
</form>

    </div>
    <section id="complaint" class="ab">
        <?php
        $servername = 'localhost';
        $username = 'root';
        $password = '';
        $dbname = 'maintanence';

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

       // Use the selected equipment value in the SQL query
$selectedEquipment = isset($_GET['equipment']) ? mysqli_real_escape_string($conn, $_GET['equipment']) : '';
$searchTerm = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
if (!empty($selectedEquipment)) {
    $sql = "SELECT * FROM location WHERE 
            equipment = '$selectedEquipment' AND 
            (building LIKE '%$searchTerm%' OR room LIKE '%$searchTerm%' OR eidd LIKE '%$searchTerm%')";
    $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="box">';
                echo '<a href="acde1.php?eidd=' . $row['eidd'] . '&name=' . $row['equipment'] . '">';

                // Display image based on the equipment type
                switch ($row['equipment']) {
                    case 'ac':
                        echo '<img src="acimage.png" alt="AC Image">';
                        break;
                    case 'fan':
                        echo '<img src="fan.png" alt="Fan Image">';
                        break;
                    case 'generator':
                        echo '<img src="gen.png" alt="Generator Image">';
                        break;
                    case 'sockets':
                        echo '<img src="img/sockets.jpg" alt="Sockets Image">';
                        break;
                    case 'light':
                        echo '<img src="img/bulb.jpg" alt="Light Image">';
                        break;
                    default:
                        // Add a default image or handle other cases if needed
                        echo '<img src="defaultimage.png" alt="Default Image">';
                        break;
                }

                echo '<strong>Equipment Id:</strong> ' . $row['eidd'] . '<br>';
                echo '<strong>Equipment Type:</strong> ' . $row['equipment'] . '<br>';
                echo '<strong>Building:</strong> ' . $row['building'] . '<br>';
                echo '<strong>Room:</strong> ' . $row['room'] . '<br>';
                // Add more fields as needed
                echo '</a>';
                echo '</div>';
            }
        } }else {
            echo "0 results";
        }
        $conn->close();
        ?>
    </section>
</body>

</html>
