<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            font-size: 16px;
        }

        header,
        nav {
            background-color: #1c0d3f;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav li {
            display: inline;
            margin-right: 20px;
            font-size: 16px;
        }

        a {
            text-decoration: none;
            color: white;
        }

        main {
            padding: 20px;
            text-align: center;
        }

        img.profile-pic {
            border-radius: 50%;
            border: 5px solid #4a148c;
            margin-bottom: 20px;
        }

        h1 {
            margin-top: 0;
            color: #4a148c;
        }

        section {
            margin-bottom: 30px;
            padding: 20px;
            border: 2px solid #4a148c;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        footer {
            text-align: center;
            padding: 10px;
            background-color: #4a148c;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>

<body>
    <header>
        <h2>My Profile</h2>
    </header>

    <nav>
        <ul>
            <li><a href="supervisordashboard.php">Home</a></li>
            <li><a href="viewissue.php">View Issue</a></li>
            <li><a href="choose.php">Assign Issue</a></li>
            <li><a href="mainstatus.php">Work Status</a></li>
            <li><a href="Rating.php">Rating</a></li>
            <li><a href="mainlogin.php">Logout</a></li>
        </ul>
    </nav>

    <main>
        <img class="profile-pic"
            src="https://thumbs.dreamstime.com/b/anonimos-icon-profie-social-network-over-color-background-differnt-uses-icon-social-profile-148257454.jpg"
            alt="Anonimos Icon" width="120" height="120">

        <?php
        $conn = mysqli_connect("localhost", "root", "", "maintanence");
        session_start();
        $sql = "SELECT role, name, dob, mobnum FROM login WHERE id=9";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $role = $row['role'];
            $name = $row['name'];
            $dob = $row['dob'];
            $mobnum = $row['mobnum'];
            echo '<h1>My Profile</h1>';
            echo '<section>';
            echo '<p><strong>Name:</strong> ' . $name . '</p>';
            echo '<p><strong>Role:</strong> ' . $role . '</p>';
            echo '<p><strong>DOB:</strong> ' . $dob . '</p>';
            echo '<p><strong>Mobile No:</strong> ' . $mobnum . '</p>';
            echo '</section>';
        }
        ?>
    </main>

</body>

</html>
