<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electrical Maintanence</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        
        header {
            background-color: #1c0d3f;
            color: white;
            padding: 10px;
            text-align: center;
        }
        
        nav {
            background-color: #311249;
            color: white;
            padding: 10px;
            text-align: center;
        }
        
        ul {
            list-style: none;
            padding: 0;
        }
        
        li {
            display: inline;
            margin-right: 20px;
        }
        
        a {
            text-decoration: none;
            color: white;
        }
        
        main {
            padding: 20px;
        }
        
        section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        section h2{
            text-align: center;
        }
        h2 {
            margin-top: 0;
        }
        form {
  border: 1px solid #ccc;
  padding: 20px;
}

label {
  display: block;
  margin-bottom: 10px;
}

input, select {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

button {
  background-color: #333;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #555;
}
    </style>
</head>
<body>
    <header>
        <h1>My Profile</h1>
    </header>
    
    <nav>
        <ul>
            <li><a href="appdashboard.php">Home</a></li>
            <li><a href="mainlogin.php">Logout</a></li>
        </ul>
    </nav>
    <br><br>
    <center>
    <img src="https://thumbs.dreamstime.com/b/anonimos-icon-profie-social-network-over-color-background-differnt-uses-icon-social-profile-148257454.jpg" alt="Anonimos Icon" width="90" height="80">
    
    <?php
$conn = mysqli_connect("localhost", "root", "", "maintanence");
session_start();
$sql = "SELECT role, name, dob, mobnum FROM login WHERE id=1";
$result = mysqli_query($conn, $sql);
if ($result) {
    $row = mysqli_fetch_assoc($result);
     $role = $row['role'];
     $name = $row['name'];
     $dob = $row['dob'];
     $mobnum = $row['mobnum'];
     //echo $name;
    echo '<h1>My Profile</h1><br></br>';
    echo '<tr><td>Name:</td> <td>'.$name.'</td></tr><br></br>';
    echo '<tr><td>Role:</td> <td>'.$role.'</td></tr><br></br>';
    echo '<tr><td>DOB:</td> <td>'.$dob.'</td></tr><br></br>';
    echo '<tr><td>Mobile.No:</td> <td>'.$mobnum.'</td></tr><br></br>';


}

    
    ?>
    </center>


  
    
<!--<form id="add-employee-form" >
    
    <label for="employee-name"> Name:</label>
    <input type="text" id="employee-name" name="employee-name" required>
    <label for="dob">Date of Birth:</label>
    <input type="Date" name="dob" required>
    <label for="mob_no">Mobile no:</label>
    <input type="big int" name="mob_no" required>
    <label for="email">Email</label>
    <input type="varchar" name="Email" required> 
    <label for="employee-role">Designation:</label>
    <select id="employee-role" name="employee-role">
      <option value="supervisor">supervisor</option>
      <option value="manager">Manager</option>
      <option value="worker">worker</option>
    </select>
  </form>-->
    
    <footer>
        <a href="mainlogin.php">Logout</a>
    
    </footer>
</body>
</html>